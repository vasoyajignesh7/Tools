EverMemo[![Build Status](https://travis-ci.org/daimajia/EverMemo.png?branch=master)](https://travis-ci.org/daimajia/EverMemo)
========

A simple memo app.

About
----------
Frok from [daimajia/EverMemo](https://github.com/daimajia/EverMemo), what is diff:   
* App name, icon;  
* Change the default title of a memo to the time it's created;


TODO
----------
* Lock pattern;
* Markdown support;
* Night mode like [Alternote](http://alternoteapp.com/);
* New application id, maybe;
