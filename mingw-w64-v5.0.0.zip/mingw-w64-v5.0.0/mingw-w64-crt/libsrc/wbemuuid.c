#include <windows.h>
#include <ole2.h>

#include <initguid.h>
#include <wbemcli.h>
