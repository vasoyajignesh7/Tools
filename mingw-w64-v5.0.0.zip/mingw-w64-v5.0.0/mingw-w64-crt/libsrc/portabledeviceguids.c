#include <propsys.h>

#include <initguid.h>
#include <portabledevicetypes.h>
