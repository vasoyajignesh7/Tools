
#include <portabledevicetypes.h>

#include <initguid.h>
#include <sensors.h>
#include <sensorsapi.h>
