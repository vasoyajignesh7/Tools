
#include <windows.h>
#include <ocidl.h>
#include <oaidl.h>

#include <initguid.h>
#include <sapi.h>
