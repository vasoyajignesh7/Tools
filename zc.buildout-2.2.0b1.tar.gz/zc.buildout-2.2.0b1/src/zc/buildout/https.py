# HTTPS Handler for requests suitable for use in setuptools/distribute

import logging
import requests
import urllib2

logger = logging.getLogger(__name__)

class HTTPSHandler(urllib2.BaseHandler):

    def https_open(self, request):
        logger.debug("open %s", request.get_full_url())
        r = requests.get(
            request.get_full_url(),
            headers=request.headers,
            stream=True,
            verify=True)
        return r.raw


def install():
    logger.debug("Installing HTTPSHandler")
    urllib2.install_opener(urllib2.build_opener(HTTPHandler))
